import os
import glob
import numpy
import dadi

os.chdir('C:/Users/16238/Documents/segtetraploid_iso/segtetraploid_iso_fs')
print("begin")

# Remove inapplicable parameters

nubot = ["0.1","0.25","0.5"]
T1 = ["0.5", "1", "1.5", "2"]
T2 = ["0.25", "0.5", "1"]
dij = ["5e-07", "5e-06","5e-05"]

for w in nubot:

  for x in T1:

      for y in T2:

          for z in dij:
            os.chdir('C:/Users/16238/Documents/segbottle/segbottle_'+ str( w ) +'_x_'+str(y))


            name= ("segtetraploid_bottleneck_" +str(w)+"_"+ str( x ) + "_" + str( y ) + "_" + str( z ) + "_*_*.fs")
            print(name)
            filenames = glob.glob("segtetraploid_bottleneck_" +str(w)+"_"+ str( x ) + "_" + str( y ) + "_" + str( z ) + "_*_*.fs")

            spectra= [0]*41
            i=0

            for entry in filenames:
              spectra = numpy.add(spectra, dadi.Spectrum.from_file(entry))
              i+=1
            print(i) #says how many files were found by glob
            print (spectra) #prints sum of all matching fs
            print (len(spectra)) #prints how many numbers are in the set above; it should match "spectra="
            avg= spectra/5000 #divides by the number of files found
            print (avg)
            fs= dadi.Spectrum(avg)
            os.chdir('C:/Users/16238/Documents/Chimps Project/segbottle/average_fs')  #Switch to directory to save files to
            fs.to_file('avg_segtetraploid_' + str( w ) + '_'+ str( x ) + '_' + str( y ) + '_' + str( z ) + '.fs') # Save with appropriate filename
            os.chdir('C:/Users/16238/Documents/segtetraploid_iso/segtetraploid_iso_fs') #Switch back to the original directory

