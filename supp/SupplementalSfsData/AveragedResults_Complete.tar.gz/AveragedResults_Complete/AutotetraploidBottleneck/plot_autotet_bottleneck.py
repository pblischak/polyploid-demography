#!/usr/bin/env python3

import dadi
import matplotlib.pyplot as plt
import numpy as np

def main():
    for nu in [0.1,0.25,0.5]:
        for T in [0.5,1.0,1.5,2.0]:
            data = dadi.Spectrum.from_file(
                f"autotetraploid_bottleneck_{nu}_{T}_x.fs"
            )
            ns = data.sample_sizes
            pts_l = [60,70,80]
            func = dadi.Demographics1D.two_epoch
            func_ex = dadi.Numerics.make_extrap_log_func(func)
            model = func_ex([nu,T], ns, pts_l)
            theta = dadi.Inference.optimal_sfs_scaling(model, data)
            print(f"Nu: {nu}, T: {T}, Theta: {theta}")
            dadi.Plotting.plot_1d_comp_multinom(model, data)
            plt.show()


if __name__ == "__main__":
    main()
