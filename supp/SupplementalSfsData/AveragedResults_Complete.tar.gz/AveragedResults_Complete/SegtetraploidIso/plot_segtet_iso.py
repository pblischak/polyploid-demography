#!/usr/bin/env python3

import dadi
import matplotlib.pyplot as plt
import numpy as np

def segtetraploid_iso(params, ns, pts):
    """
    params = (nu,T1,T2,dij)
    ns = (n1,n2)
    Split into two populations of specifed size.
    nu: Size of populations after split.
    T: Time in the past of split (in units of 2*Na generations)
    n1,n2: Sample sizes of resulting Spectrum
    pts: Number of grid points to use in integration.
    """
    nu,T1,T2,dij = params
    new_ns = [int(ns[0]/2),int(ns[0]/2)]

    xx = dadi.Numerics.default_grid(pts)

    phi = dadi.PhiManip.phi_1D(xx)
    phi = dadi.PhiManip.phi_1D_to_2D(xx, phi)

    phi = dadi.Integration.two_pops(phi, xx, T1, nu, nu)
    phi = dadi.Integration.two_pops(phi, xx, T2, nu, nu, m12=dij, m21=dij)

    fs_2D = dadi.Spectrum.from_phi(phi, new_ns, (xx,xx), pop_ids=['sub1','sub2'])
    fs_1D = fs_2D.combine_pops([1,2])
    return fs_1D


def main():
    func = segtetraploid_iso
    func_ex = dadi.Numerics.make_extrap_log_func(func)
    pts_l = [60,70,80]
    for e_ij in [5e-05,5e-06,5e-07]:
        for T1 in [0.5,1,1.5,2]:
            for T2 in [0.25,0.5,1]:
                data = dadi.Spectrum.from_file(
                    f"avg_segtetraploid_{T1}_{T2}_{e_ij}.fs"
                )
                ns = data.sample_sizes
                model = func_ex([1.0,T1,T2,2000*e_ij], ns, pts_l)
                theta = dadi.Inference.optimal_sfs_scaling(model, data)
                print(f"E_ij: {e_ij}, T1: {T1}, T2: {T2}, Theta: {theta}")
                dadi.Plotting.plot_1d_comp_multinom(model, data)
                plt.show()


if __name__ == "__main__":
    main()
