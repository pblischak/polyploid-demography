#!/usr/bin/env python3

import dadi
import matplotlib.pyplot as plt
import numpy as np

def allotetraploid_iso(params, ns, pts):
    """
    params = (nu,T)
    ns = (n1,n2)
    Split into two populations of specifed size.
    nu: Size of populations after split.
    T: Time in the past of split (in units of 2*Na generations)
    n1,n2: Sample sizes of resulting Spectrum
    pts: Number of grid points to use in integration.
    """
    nu,T = params
    new_ns = [int(ns[0]/2),int(ns[0]/2)]

    xx = dadi.Numerics.default_grid(pts)

    phi = dadi.PhiManip.phi_1D(xx)
    phi = dadi.PhiManip.phi_1D_to_2D(xx, phi)

    phi = dadi.Integration.two_pops(phi, xx, T, nu, nu)

    fs_2D = dadi.Spectrum.from_phi(phi, new_ns, (xx,xx), pop_ids=['sub1','sub2'])
    fs_1D = fs_2D.combine_pops([1,2])
    return fs_1D


def main():
    func = allotetraploid_iso
    func_ex = dadi.Numerics.make_extrap_log_func(func)
    pts_l = [60,70,80]
    for T in [0.5,1.0,1.5,2.0]:
        data = dadi.Spectrum.from_file(
            f"allotetraploid_iso_{T}_x_x.fs"
        )
        ns = data.sample_sizes
        model = func_ex([1.0,T], ns, pts_l)
        theta = dadi.Inference.optimal_sfs_scaling(model, data)
        print(f"T: {T}, Theta: {theta}")
        dadi.Plotting.plot_1d_comp_multinom(model, data)
        plt.show()


if __name__ == "__main__":
    main()
