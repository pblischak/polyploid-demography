#!/usr/bin/env python3

import dadi
import matplotlib.pyplot as plt
import numpy as np

def main():
    data = dadi.Spectrum.from_file("auto_snm2_x_x.fs")
    ns = data.sample_sizes
    pts_l = [60,70,80]
    func = dadi.Demographics1D.snm
    func_ex = dadi.Numerics.make_extrap_log_func(func)
    model = func_ex([], ns, pts_l)
    theta = dadi.Inference.optimal_sfs_scaling(model, data)
    print(f"Theta: {theta}")
    plt.semilogy(theta * model, '-ob', markersize=8)
    plt.semilogy(data, '-og', markersize=8)
    # dadi.Plotting.plot_1d_comp_multinom(model, data)
    plt.show()


if __name__ == "__main__":
    main()
