import os
import numpy
os.chdir('C:/Users/16238/Documents/results/allotetraploid_iso')
import dadi
data = dadi.Spectrum.from_file('allotetraploid_iso_x_x_x.fs') # replace with appropriate filename
ns = data.sample_sizes
pts= 50
pts_l = [60,70,80]
func = dadi.Demographics1D.snm
upper_bound = []
lower_bound = []
p0 = []
func_ex = dadi.Numerics.make_extrap_log_func(func)
#skipped optimization since there are no parameters
popt = []
print('Best-fit parameters: {0}'.format(popt))
# Calculate the best-fit model AFS.
model = func_ex(popt, ns, pts_l)
# Likelihood of the data given the model AFS.
ll_model = dadi.Inference.ll_multinom(model, data)
print('Maximum log composite likelihood: {0}'.format(ll_model))
# The optimal value of theta given the model.
theta = dadi.Inference.optimal_sfs_scaling(model, data)
print('Optimal value of theta: {0}'.format(theta))
# Plot a comparison of the resulting fs with the data.
import pylab
pylab.figure(1)
dadi.Plotting.plot_1d_comp_multinom(model, data)
# Save the figure
pylab.savefig('average_data1.png', dpi=250)
pylab.show()